 $("#mapDiv").append(googleMap);


